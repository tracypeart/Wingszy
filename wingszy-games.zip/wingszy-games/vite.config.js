import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 3000,
    proxy: {
      // boardgame.io game server (see src/server.js) runs on 8000
      '/games': 'http://localhost:8000',
    },
  },
});
