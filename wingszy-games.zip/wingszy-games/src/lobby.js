/**
 * Thin wrapper around boardgame.io's LobbyClient. This is the actual
 * "send a game invite" flow: one player creates a match and gets a
 * matchID, that ID goes into the invite link, the second (and any
 * further) player(s) join by ID and get back playerCredentials that
 * authenticate their future moves.
 *
 * A match MUST be created via the lobby before any Client can connect
 * to it — connecting to an arbitrary matchID that was never created
 * will hang waiting for a match that doesn't exist. That's the bug
 * from the first pass at this dev harness.
 */
import { LobbyClient } from 'boardgame.io/dist/esm/client.js';

const lobby = new LobbyClient({ server: 'http://localhost:8000' });

/** Host creates a match. Returns { matchID }. */
export async function createMatch(gameName, numPlayers, setupData) {
  return lobby.createMatch(gameName, { numPlayers, setupData });
}

/** Each player (including the host) joins to get their credentials. */
export async function joinMatch(gameName, matchID, playerID, playerName) {
  return lobby.joinMatch(gameName, matchID, { playerID, playerName });
}

/** Fetch current match state — useful for showing "who's joined so far". */
export async function getMatch(gameName, matchID) {
  return lobby.getMatch(gameName, matchID);
}
