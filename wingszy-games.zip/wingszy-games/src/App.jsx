import React, { useState } from 'react';
import { Client } from 'boardgame.io/dist/esm/react.js';
import { SocketIO } from 'boardgame.io/dist/esm/multiplayer.js';
import { createMatch, joinMatch } from './lobby.js';

import { ThisOrThat } from './games/thisOrThat.js';
import { RedGreenFlag } from './games/redGreenFlag.js';
import { CupidDraft } from './games/cupidDraft.js';
import { BuildOurDate } from './games/buildOurDate.js';
import { AICompatibility } from './games/aiCompatibility.js';

import { ThisOrThatBoard } from './boards/ThisOrThatBoard.jsx';
import { RedGreenFlagBoard } from './boards/RedGreenFlagBoard.jsx';
import { CupidDraftBoard } from './boards/CupidDraftBoard.jsx';
import { BuildOurDateBoard } from './boards/BuildOurDateBoard.jsx';
import { AICompatibilityBoard } from './boards/AICompatibilityBoard.jsx';

const SERVER = 'http://localhost:8000';

// One Client per game — each pairs a game definition with its board and
// points at the shared boardgame.io server over Socket.IO.
const GAMES = {
  'this-or-that': {
    label: 'This or That',
    numPlayers: 2,
    client: Client({
      game: ThisOrThat,
      board: ThisOrThatBoard,
      multiplayer: SocketIO({ server: SERVER }),
    }),
  },
  'red-green-flag': {
    label: 'Red Flag / Green Flag',
    numPlayers: 2,
    client: Client({
      game: RedGreenFlag,
      board: RedGreenFlagBoard,
      multiplayer: SocketIO({ server: SERVER }),
    }),
  },
  'cupid-draft': {
    label: 'Cupid Draft',
    numPlayers: 4, // 1 subject + 3 friends by default; adjust per match
    client: Client({
      game: CupidDraft,
      board: CupidDraftBoard,
      multiplayer: SocketIO({ server: SERVER }),
    }),
  },
  'build-our-date': {
    label: 'Build Our Perfect Date',
    numPlayers: 2,
    client: Client({
      game: BuildOurDate,
      board: BuildOurDateBoard,
      multiplayer: SocketIO({ server: SERVER }),
    }),
  },
  'ai-compatibility': {
    label: 'AI Compatibility Challenge',
    numPlayers: 2,
    client: Client({
      game: AICompatibility,
      board: AICompatibilityBoard,
      multiplayer: SocketIO({ server: SERVER }),
    }),
  },
};

export default function App() {
  const [selectedKey, setSelectedKey] = useState(null);
  // session === null: choosing whether to host or join.
  // session === { matchID, playerID, credentials }: actually playing.
  const [session, setSession] = useState(null);
  const [joinMatchID, setJoinMatchID] = useState('');
  const [joinSeat, setJoinSeat] = useState('1');
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState(null);

  if (!selectedKey) {
    return (
      <div className="lobby">
        <h1>Wingszy — Game Picker (dev harness)</h1>
        <ul>
          {Object.entries(GAMES).map(([key, g]) => (
            <li key={key}>
              <button onClick={() => setSelectedKey(key)}>{g.label}</button>
            </li>
          ))}
        </ul>
      </div>
    );
  }

  const gameKey = selectedKey; // e.g. 'this-or-that' — also the LobbyClient game name
  const { client: GameClient, numPlayers, label } = GAMES[gameKey];

  if (session) {
    return (
      <div className="game-wrapper">
        <button
          onClick={() => {
            setSession(null);
            setSelectedKey(null);
          }}
        >
          ← Back
        </button>
        <p className="invite-hint">
          Invite link for the next player: <code>?match={session.matchID}&seat=1</code>
        </p>
        <GameClient
          matchID={session.matchID}
          playerID={session.playerID}
          credentials={session.credentials}
        />
      </div>
    );
  }

  // --- host-or-join screen: this is the real invite flow --------------
  const hostNewMatch = async () => {
    setBusy(true);
    setError(null);
    try {
      const { matchID } = await createMatch(gameKey, numPlayers);
      const { playerCredentials } = await joinMatch(gameKey, matchID, '0', 'Host');
      setSession({ matchID, playerID: '0', credentials: playerCredentials });
    } catch (err) {
      setError(err.message || String(err));
    } finally {
      setBusy(false);
    }
  };

  const joinExistingMatch = async () => {
    setBusy(true);
    setError(null);
    try {
      const { playerCredentials } = await joinMatch(
        gameKey,
        joinMatchID.trim(),
        joinSeat,
        'Guest'
      );
      setSession({
        matchID: joinMatchID.trim(),
        playerID: joinSeat,
        credentials: playerCredentials,
      });
    } catch (err) {
      setError(err.message || String(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="lobby">
      <button onClick={() => setSelectedKey(null)}>← Back</button>
      <h2>{label}</h2>
      {error && <p className="error">{error}</p>}

      <section>
        <h3>Start a new match</h3>
        <button disabled={busy} onClick={hostNewMatch}>
          Create match & join as seat 0
        </button>
      </section>

      <section>
        <h3>Join an existing match</h3>
        <label>
          Match ID
          <input value={joinMatchID} onChange={(e) => setJoinMatchID(e.target.value)} />
        </label>
        <label>
          Seat
          <select value={joinSeat} onChange={(e) => setJoinSeat(e.target.value)}>
            {Array.from({ length: numPlayers - 1 }, (_, i) => String(i + 1)).map((id) => (
              <option key={id} value={id}>
                {id}
              </option>
            ))}
          </select>
        </label>
        <button disabled={busy || !joinMatchID} onClick={joinExistingMatch}>
          Join match
        </button>
      </section>
    </div>
  );
}
