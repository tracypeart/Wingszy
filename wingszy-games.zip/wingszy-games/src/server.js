import { Server, Origins } from 'boardgame.io/dist/cjs/server.js';
import { ThisOrThat } from './games/thisOrThat.js';
import { RedGreenFlag } from './games/redGreenFlag.js';
import { CupidDraft } from './games/cupidDraft.js';
import { BuildOurDate } from './games/buildOurDate.js';
import { AICompatibility } from './games/aiCompatibility.js';
import { generateCompatibilitySummary } from './ai/generateSummary.js';

const server = Server({
  games: [ThisOrThat, RedGreenFlag, CupidDraft, BuildOurDate, AICompatibility],
  origins: [Origins.LOCALHOST], // swap for your app's real origin(s) in production
});

// --- AI summary hook ---------------------------------------------------
// boardgame.io moves can't call external APIs (see aiCompatibility.js),
// so we watch for completed AI Compatibility matches and generate the
// summary out-of-band, then stash it wherever your app reads it from
// (Postgres/Supabase table, Redis, etc. — NOT boardgame.io's own store).
const { db } = server;
const originalSetState = db.setState.bind(db);
db.setState = async (matchID, state, ...args) => {
  const result = await originalSetState(matchID, state, ...args);
  if (state?.ctx?.gameover && matchID.startsWith('ai-compatibility')) {
    const rounds = state.G.rounds;
    generateCompatibilitySummary(rounds).catch((err) =>
      console.error('AI summary generation failed for match', matchID, err)
    );
  }
  return result;
};
// -------------------------------------------------------------------------

const PORT = process.env.PORT || 8000;
server.run(PORT, () => {
  console.log(`Wingszy game server running on http://localhost:${PORT}`);
});
