import React, { useState } from 'react';

export function CupidDraftBoard({ G, ctx, moves, playerID }) {
  const isSubject = playerID === '0';
  const isMyTurn = ctx.currentPlayer === playerID;

  if (ctx.gameover) {
    const winner = G.nominations.find((n) => n.friendID === ctx.gameover.winnerFriendID);
    return (
      <div className="game-over">
        <h2>🪽 Sarah picked...</h2>
        <p>
          <strong>{winner.name}</strong>, nominated by seat {winner.friendID}
        </p>
        <p>"{winner.pitch}"</p>
      </div>
    );
  }

  if (ctx.phase === 'nominating') {
    return (
      <div className="cupid-draft">
        <h2>Cupid Draft — Nominating</h2>
        {isSubject && <p>Sit tight — your friends are drafting candidates.</p>}
        {!isSubject && isMyTurn && <NominationForm onSubmit={moves.nominate} />}
        {!isSubject && !isMyTurn && <p>Waiting for your turn to nominate…</p>}

        <ul className="nominations-so-far">
          {G.nominations.map((n, i) => (
            <li key={i}>
              {isSubject ? `${n.name} — "${n.pitch}"` : `Nomination #${i + 1} submitted`}
            </li>
          ))}
        </ul>
      </div>
    );
  }

  if (ctx.phase === 'reviewing') {
    return (
      <div className="cupid-draft">
        <h2>Cupid Draft — Sarah's Turn</h2>
        {isSubject ? (
          <div className="pitches">
            {G.nominations.map((n) => (
              <div key={n.friendID} className="pitch-card">
                <h3>{n.name}</h3>
                <p>{n.pitch}</p>
                <button onClick={() => moves.chooseWinner(n.friendID)}>
                  Pick {n.name}
                </button>
              </div>
            ))}
          </div>
        ) : (
          <p>Sarah's reviewing the pitches now…</p>
        )}
      </div>
    );
  }

  return null;
}

function NominationForm({ onSubmit }) {
  const [name, setName] = useState('');
  const [pitch, setPitch] = useState('');

  const submit = (e) => {
    e.preventDefault();
    if (!name.trim() || !pitch.trim()) return;
    onSubmit(name.trim(), pitch.trim());
  };

  return (
    <form onSubmit={submit} className="nomination-form">
      <input
        placeholder="Who are you nominating?"
        value={name}
        onChange={(e) => setName(e.target.value)}
      />
      <textarea
        placeholder="Make your case in 30 seconds worth of words…"
        value={pitch}
        onChange={(e) => setPitch(e.target.value)}
      />
      <button type="submit">Submit nomination</button>
    </form>
  );
}
