import React, { useState } from 'react';

export function BuildOurDateBoard({ G, ctx, moves }) {
  const [plan, setPlan] = useState({
    restaurant: 0,
    activity: 0,
    dessert: 0,
    surprise: 0,
  });
  const [submitted, setSubmitted] = useState(false);

  const spent = Object.values(plan).reduce((a, b) => a + Number(b || 0), 0);
  const remaining = G.budget - spent;

  if (ctx.gameover && G.revealed) {
    return (
      <div className="game-over">
        <h2>Your combined dream date 🎯</h2>
        {Object.entries(G.revealed).map(([id, p]) => (
          <div key={id} className="plan-card">
            <h3>Seat {id}'s plan</h3>
            <ul>
              <li>Restaurant: ${p.restaurant}</li>
              <li>Activity: ${p.activity}</li>
              <li>Dessert: ${p.dessert}</li>
              <li>Surprise: ${p.surprise}</li>
            </ul>
            <p>Total spent: ${p.spent} / ${G.budget}</p>
          </div>
        ))}
      </div>
    );
  }

  if (submitted) {
    return <p>Plan submitted — waiting on the other player…</p>;
  }

  const update = (field) => (e) =>
    setPlan((p) => ({ ...p, [field]: Number(e.target.value) || 0 }));

  const submit = () => {
    if (remaining < 0) return;
    moves.submitPlan(plan);
    setSubmitted(true);
  };

  return (
    <div className="build-our-date">
      <h2>Build the Perfect Date — ${G.budget} budget</h2>
      <p className={remaining < 0 ? 'over-budget' : ''}>
        Remaining: ${remaining}
      </p>

      {['restaurant', 'activity', 'dessert', 'surprise'].map((field) => (
        <label key={field}>
          {field[0].toUpperCase() + field.slice(1)}
          <input
            type="number"
            min="0"
            value={plan[field]}
            onChange={update(field)}
          />
        </label>
      ))}

      <button disabled={remaining < 0} onClick={submit}>
        Lock in my plan
      </button>
    </div>
  );
}
