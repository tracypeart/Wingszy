import React, { useState, useEffect } from 'react';

export function AICompatibilityBoard({ G, ctx, moves }) {
  const [answer, setAnswer] = useState('');
  const [answered, setAnswered] = useState(false);
  const question = G.questions[G.currentPromptIndex];

  useEffect(() => {
    setAnswered(false);
    setAnswer('');
  }, [G.currentPromptIndex]);

  if (ctx.gameover) {
    return (
      <div className="game-over">
        <h2>Chemistry check complete 🤖</h2>
        <p>
          Your compatibility summary is being generated — check back in a
          moment (see src/ai/generateSummary.js for the hook that
          produces it out-of-band).
        </p>
      </div>
    );
  }

  if (!question) return null;

  const submit = () => {
    if (!answer.trim()) return;
    moves.submitAnswer(answer.trim());
    setAnswered(true);
  };

  return (
    <div className="ai-compatibility">
      <h2>
        Question {G.currentPromptIndex + 1} / {G.questions.length}
      </h2>
      <p className="question">{question}</p>

      {answered ? (
        <p>Waiting on the other player…</p>
      ) : (
        <>
          <textarea
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
            placeholder="Answer honestly — no one sees this until you both submit."
          />
          <button onClick={submit}>Submit</button>
        </>
      )}
    </div>
  );
}
