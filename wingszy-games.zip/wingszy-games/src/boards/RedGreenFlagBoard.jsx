import React, { useState, useEffect } from 'react';

export function RedGreenFlagBoard({ G, ctx, moves }) {
  const [answered, setAnswered] = useState(false);
  const prompt = G.prompts[G.currentPromptIndex];
  const lastRound = G.rounds[G.rounds.length - 1];

  useEffect(() => setAnswered(false), [G.currentPromptIndex]);

  if (ctx.gameover) {
    return (
      <div className="game-over">
        <h2>All flags reviewed 🚩💚</h2>
        <p>{G.rounds.length} scenarios discussed. Talk through the disagreements!</p>
      </div>
    );
  }

  if (!prompt) return null;

  const vote = (choice) => {
    moves.submitAnswer(choice);
    setAnswered(true);
  };

  return (
    <div className="red-green-flag">
      <h2>
        Scenario {G.currentPromptIndex + 1} / {G.prompts.length}
      </h2>
      <p className="scenario">"{prompt}"</p>

      {answered ? (
        <p>Waiting on the other player…</p>
      ) : (
        <div className="choices">
          <button className="green" onClick={() => vote('green')}>
            🟢 Green flag
          </button>
          <button className="red" onClick={() => vote('red')}>
            🔴 Red flag
          </button>
        </div>
      )}

      {lastRound && (
        <div className="reveal">
          <p>"{G.prompts[lastRound.promptIndex]}"</p>
          <p>
            {Object.entries(lastRound.answers)
              .map(([id, v]) => `Seat ${id}: ${v === 'green' ? '🟢' : '🔴'}`)
              .join('   ')}
          </p>
        </div>
      )}
    </div>
  );
}
