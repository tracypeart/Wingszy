import React, { useState, useEffect } from 'react';

export function ThisOrThatBoard({ G, ctx, moves, playerID }) {
  const [hasAnsweredThisRound, setHasAnsweredThisRound] = useState(false);
  const prompt = G.prompts[G.currentPromptIndex];
  const lastRound = G.rounds[G.rounds.length - 1];

  // reset "answered" flag whenever a new prompt comes up
  useEffect(() => {
    setHasAnsweredThisRound(false);
  }, [G.currentPromptIndex]);

  if (ctx.gameover) {
    return (
      <div className="game-over">
        <h2>That's the deck! 🎉</h2>
        <MatchSummary rounds={G.rounds} prompts={G.prompts} />
      </div>
    );
  }

  if (!prompt) return null;

  const pick = (choice) => {
    moves.submitAnswer(choice);
    setHasAnsweredThisRound(true);
  };

  return (
    <div className="this-or-that">
      <h2>
        Round {G.currentPromptIndex + 1} / {G.prompts.length}
      </h2>

      {hasAnsweredThisRound ? (
        <p>Waiting on the other player…</p>
      ) : (
        <div className="choices">
          <button onClick={() => pick('a')}>{prompt.a}</button>
          <span>or</span>
          <button onClick={() => pick('b')}>{prompt.b}</button>
        </div>
      )}

      {/* Show the previous round's reveal so players see it land together */}
      {lastRound && (
        <RoundReveal round={lastRound} prompt={G.prompts[lastRound.promptIndex]} />
      )}
    </div>
  );
}

function RoundReveal({ round, prompt }) {
  const answers = Object.values(round.answers);
  const matched = answers[0] === answers[1];
  return (
    <div className="reveal">
      <p>
        {prompt.a} vs {prompt.b}
      </p>
      <p>{matched ? '❤️ Match!' : '🤔 Opposite — tell each other why.'}</p>
    </div>
  );
}

function MatchSummary({ rounds, prompts }) {
  const matches = rounds.filter((r) => {
    const a = Object.values(r.answers);
    return a[0] === a[1];
  }).length;
  return (
    <p>
      You matched on {matches} of {rounds.length} rounds.
    </p>
  );
}
