/**
 * Cupid Draft: seat '0' is the subject ("Sarah"); seats '1'..'N' are her
 * friends acting as wingpeople. This is a clean fit for boardgame.io's
 * default turn model — no stages needed, since nominations happen one
 * friend at a time, in order, exactly like a normal turn-based game.
 *
 * Phase 1 (nominating): each friend seat, in turn order, submits one
 *   nomination (name + a short pitch). Play passes automatically once
 *   every friend seat has nominated once.
 * Phase 2 (reviewing): only the subject (seat '0') can act — they read
 *   every pitch and lock in a favorite, ending the match.
 */

export const CupidDraft = {
  name: 'cupid-draft',

  setup: ({ ctx }) => ({
    nominations: [], // [{ friendID, name, pitch }]
    winnerFriendID: null,
  }),

  phases: {
    nominating: {
      start: true,
      turn: {
        // seat '0' is the subject and never nominates — turn order
        // walks the remaining seats.
        order: {
          first: () => 1,
          next: ({ ctx }) => (ctx.playOrderPos + 1) % ctx.numPlayers,
        },
      },
      moves: {
        nominate: ({ G, playerID }, name, pitch) => {
          G.nominations.push({ friendID: playerID, name, pitch });
        },
      },
      endIf: ({ G, ctx }) => G.nominations.length >= ctx.numPlayers - 1,
      next: 'reviewing',
    },

    reviewing: {
      turn: {
        order: {
          first: () => 0, // subject's seat
          next: () => 0,
        },
      },
      moves: {
        chooseWinner: ({ G, events }, friendID) => {
          G.winnerFriendID = friendID;
          events.endGame({ winnerFriendID: friendID });
        },
      },
    },
  },

  minPlayers: 3, // subject + at least 2 wingpeople
  maxPlayers: 7, // subject + up to 6 wingpeople
};
