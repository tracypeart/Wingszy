// Unit-tests the actual reducer logic in simultaneousStage.js directly,
// against fake G/ctx shapes shaped like what boardgame.io would pass in.
// This is import-clean (no boardgame.io runtime needed) and verifies the
// one piece of custom logic this whole approach depends on.
import {
  simultaneousAnswerMove,
  allAnswered,
  revealAnswers,
  stripPendingAnswers,
} from './simultaneousStage.js';

function assert(cond, msg) {
  if (!cond) {
    console.error('FAIL:', msg);
    process.exitCode = 1;
  } else {
    console.log('OK:', msg);
  }
}

const ctx = { playOrder: ['0', '1'] };
const G = {
  currentPromptIndex: 0,
  rounds: [],
  secret: { pendingAnswers: {} },
};

// simultaneousAnswerMove is a { move, client } descriptor (client: false,
// since it touches G.secret) — call the inner .move function directly.
assert(
  simultaneousAnswerMove.client === false,
  'move is marked client:false since it touches G.secret'
);

// Player 0 submits.
simultaneousAnswerMove.move({ G, playerID: '0' }, 'a');
assert(!allAnswered(G, ctx), 'not all-answered after only one player submits');

// Player 1 submits.
simultaneousAnswerMove.move({ G, playerID: '1' }, 'b');
assert(allAnswered(G, ctx), 'all-answered once every seat in playOrder has submitted');

revealAnswers(G, ctx);
assert(G.rounds.length === 1, 'revealAnswers pushed exactly one round record');
assert(
  G.rounds[0].answers['0'] === 'a' && G.rounds[0].answers['1'] === 'b',
  'revealed round preserves each seat\'s actual submitted answer'
);
assert(
  Object.keys(G.secret.pendingAnswers).length === 0,
  'pendingAnswers cleared after reveal, ready for next round'
);
assert(G.currentPromptIndex === 1, 'prompt index advanced by exactly one');

// playerView strips the whole `secret` key regardless of its contents.
const stripped = stripPendingAnswers({ G });
assert(stripped.secret === undefined, 'playerView strips secret before reaching a client');
assert(stripped.rounds.length === 1, 'playerView still exposes public state (rounds)');

console.log(process.exitCode ? '\nSanity check FAILED' : '\nAll sanity checks passed ✅');
