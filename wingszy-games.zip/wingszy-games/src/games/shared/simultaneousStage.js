/**
 * Reusable pattern for "both players answer privately at the same time,
 * then reveal together" games — This or That, Red Flag/Green Flag,
 * Build Our Perfect Date, Secret Opinion, etc.
 *
 * boardgame.io doesn't have a built-in "simultaneous move" primitive
 * (see https://github.com/boardgameio/boardgame.io/issues/828), but the
 * documented workaround is: put every player into the same STAGE at once
 * (turn.activePlayers.all), let each submit into their own private slot
 * under G.secret, and only copy answers into the PUBLIC part of G once
 * everyone has submitted. playerView strips G.secret before it ever
 * reaches the client, so nobody can peek at an in-progress answer.
 *
 * Usage inside a game definition:
 *
 *   import { ActivePlayers } from 'boardgame.io/core';
 *   import { simultaneousAnswerMove, allAnswered, revealAnswers } from './shared/simultaneousStage';
 *
 *   turn: {
 *     activePlayers: ActivePlayers.ALL,
 *     // endIf is a PURE PREDICATE — it decides whether to end the turn,
 *     // but boardgame.io does not allow it to mutate G. (Caught by the
 *     // live-server integration test: "object is not extensible" —
 *     // Immer freezes the draft passed into endIf.)
 *     endIf: ({ G, ctx }) => allAnswered(G, ctx),
 *     // onEnd DOES get a mutable draft — this is where the actual
 *     // reveal + advance-to-next-round mutation belongs.
 *     onEnd: ({ G, ctx, events }) => {
 *       revealAnswers(G, ctx);
 *       if (G.currentPromptIndex >= G.prompts.length) {
 *         events.endGame({ matchComplete: true });
 *       }
 *     },
 *   },
 *   moves: {
 *     submitAnswer: simultaneousAnswerMove,
 *   },
 *
 * IMPORTANT: this move is exported as a { move, client: false } descriptor,
 * not a bare function. boardgame.io runs moves optimistically on the
 * client by default for instant feedback — but a client's local G has
 * `secret` stripped out by playerView (that's the whole point of it),
 * so a move that touches G.secret will throw if boardgame.io tries to
 * run it client-side. `client: false` forces it to run on the server
 * only, where the full G (including secret) actually exists. This was
 * caught by an actual live-server integration test, not guessed —
 * moves like this fail silently in a pure in-memory test because that
 * test never exercises the optimistic-client-execution code path.
 */

/** Move: player privately submits their answer for the current round. */
export const simultaneousAnswerMove = {
  move: ({ G, playerID }, value) => {
    G.secret.pendingAnswers[playerID] = value;
  },
  client: false,
};

/** True once every player currently in the match has submitted. */
export function allAnswered(G, ctx) {
  return ctx.playOrder.every((id) => G.secret.pendingAnswers[id] !== undefined);
}

/**
 * Copies pending answers into public state, appends a round record,
 * and clears the pending slot for the next round. Mutates G — only
 * call this from a hook boardgame.io allows to mutate (turn.onEnd),
 * never from endIf (see the usage note above).
 */
export function revealAnswers(G, ctx) {
  const revealed = { ...G.secret.pendingAnswers };
  G.rounds.push({
    promptIndex: G.currentPromptIndex,
    answers: revealed,
  });
  G.secret.pendingAnswers = {};
  G.currentPromptIndex += 1;
}

/** Strips in-progress (unrevealed) answers from every client's view. */
export function stripPendingAnswers({ G }) {
  const { secret, ...publicG } = G;
  return publicG;
}
