import { ActivePlayers } from 'boardgame.io/dist/esm/core.js';
import {
  allAnswered,
  stripPendingAnswers,
} from './shared/simultaneousStage.js';

const BUDGET = 150;

/**
 * Each player privately allocates a $150 budget across restaurant /
 * activity / dessert / surprise, then both plans are revealed together.
 * Same simultaneous-stage pattern as This or That, but the "answer" is
 * a structured object instead of a single a/b value — the pattern
 * doesn't care what shape the payload is.
 */
export const BuildOurDate = {
  name: 'build-our-date',

  setup: () => ({
    budget: BUDGET,
    revealed: null, // { '0': {restaurant, activity, dessert, surprise, spent}, '1': {...} }
    secret: { pendingAnswers: {} },
  }),

  turn: {
    activePlayers: ActivePlayers.ALL,
    // Pure predicate only — see the note in shared/simultaneousStage.js
    // on why mutation can't happen in endIf.
    endIf: ({ G, ctx }) => allAnswered(G, ctx),
    // Single-round game: whenever the turn ends, both plans are in —
    // reveal and end the match in the same step.
    onEnd: ({ G, ctx, events }) => {
      G.revealed = { ...G.secret.pendingAnswers };
      events.endGame({ matchComplete: true });
    },
  },

  moves: {
    // client: false — this move touches G.secret, which is stripped from
    // the client's local state by playerView, so it must run server-side
    // only. See the detailed note in shared/simultaneousStage.js.
    submitPlan: {
      move: ({ G, playerID }, plan) => {
        const spent =
          (plan.restaurant || 0) +
          (plan.activity || 0) +
          (plan.dessert || 0) +
          (plan.surprise || 0);
        if (spent > G.budget) {
          return; // invalid move — silently ignored (client should validate first)
        }
        G.secret.pendingAnswers[playerID] = { ...plan, spent };
      },
      client: false,
    },
  },

  playerView: stripPendingAnswers,

  minPlayers: 2,
  maxPlayers: 2,
};
