import { ActivePlayers } from 'boardgame.io/dist/esm/core.js';
import prompts from '../content/redGreenFlag.json' with { type: 'json' };
import {
  simultaneousAnswerMove,
  allAnswered,
  revealAnswers,
  stripPendingAnswers,
} from './shared/simultaneousStage.js';

const ROUNDS_PER_MATCH = 8;

export const RedGreenFlag = {
  name: 'red-green-flag',

  setup: ({ random }) => ({
    prompts: random.Shuffle(prompts).slice(0, ROUNDS_PER_MATCH),
    currentPromptIndex: 0,
    rounds: [], // [{ promptIndex, answers: { '0': 'green'|'red', '1': 'green'|'red' } }]
    secret: { pendingAnswers: {} },
  }),

  turn: {
    activePlayers: ActivePlayers.ALL,
    endIf: ({ G, ctx }) => allAnswered(G, ctx),
    onEnd: ({ G, ctx, events }) => {
      revealAnswers(G, ctx);
      if (G.currentPromptIndex >= G.prompts.length) {
        events.endGame({ matchComplete: true });
      }
    },
  },

  moves: {
    // value is 'green' or 'red'
    submitAnswer: simultaneousAnswerMove,
  },

  playerView: stripPendingAnswers,

  minPlayers: 2,
  maxPlayers: 2,
};
