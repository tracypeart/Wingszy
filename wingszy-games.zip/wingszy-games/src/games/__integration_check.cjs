// End-to-end check using the REAL flow: create a match via the lobby,
// have both players join it (getting credentials), then connect two
// live Socket.IO clients against the real running server and play a
// full round. This replaces the earlier version that hung because it
// connected to a matchID that was never created via the lobby.
const { Client } = require('boardgame.io/dist/cjs/client.js');
const { SocketIO } = require('boardgame.io/dist/cjs/multiplayer.js');

const SERVER = 'http://localhost:8124';

function assert(cond, msg) {
  if (!cond) {
    console.error('FAIL:', msg);
    process.exitCode = 1;
  } else {
    console.log('OK:', msg);
  }
}

// Robust wait: resolves as soon as predicate is true, but the timeout
// fires independently via setTimeout rather than only being checked
// inside the subscribe callback (that was the bug last time — if the
// callback never fires again, the timeout branch never runs either).
function waitFor(client, predicate, timeoutMs = 5000, label = '') {
  return new Promise((resolve, reject) => {
    let done = false;
    const timer = setTimeout(() => {
      if (!done) {
        done = true;
        unsub();
        reject(new Error(`timed out waiting for: ${label}`));
      }
    }, timeoutMs);

    const check = () => {
      const state = client.getState();
      if (!done && state && predicate(state)) {
        done = true;
        clearTimeout(timer);
        unsub();
        resolve(state);
      }
    };

    const unsub = client.subscribe(check);
    check(); // in case the condition is already true
  });
}

async function main() {
  process.env.PORT = 8124;
  await import('../server.js');
  await new Promise((r) => setTimeout(r, 500)); // let the server finish binding

  const { createMatch, joinMatch } = await import('../lobby.js');
  const GAME_NAME = 'this-or-that';

  // Point our lobby helper at the test port (it defaults to :8000).
  const { LobbyClient } = require('boardgame.io/dist/cjs/client.js');
  const lobby = new LobbyClient({ server: SERVER });

  const { matchID } = await lobby.createMatch(GAME_NAME, { numPlayers: 2 });
  console.log('Created match:', matchID);

  const { playerCredentials: creds0 } = await lobby.joinMatch(GAME_NAME, matchID, {
    playerID: '0',
    playerName: 'Alice',
  });
  const { playerCredentials: creds1 } = await lobby.joinMatch(GAME_NAME, matchID, {
    playerID: '1',
    playerName: 'Bob',
  });
  console.log('Both players joined and received credentials.');

  const { ThisOrThat } = await import('./thisOrThat.js');

  const client0 = Client({
    game: ThisOrThat,
    playerID: '0',
    matchID,
    credentials: creds0,
    multiplayer: SocketIO({ server: SERVER }),
  });
  const client1 = Client({
    game: ThisOrThat,
    playerID: '1',
    matchID,
    credentials: creds1,
    multiplayer: SocketIO({ server: SERVER }),
  });

  client0.start();
  client1.start();

  // Wait for both clients to actually receive initial synced state.
  await waitFor(client0, (s) => s.G && s.G.prompts, 5000, 'client0 initial sync');
  await waitFor(client1, (s) => s.G && s.G.prompts, 5000, 'client1 initial sync');
  console.log('Both clients synced with the live server.');

  client0.moves.submitAnswer('a');
  await new Promise((r) => setTimeout(r, 300));

  const beforeReveal = client1.getState().G;
  assert(beforeReveal.rounds.length === 0, '[live server] no reveal until both answer');
  assert(beforeReveal.secret === undefined, '[live server] secret hidden from other seat');

  client1.moves.submitAnswer('b');
  await waitFor(client0, (s) => s.G.rounds.length === 1, 5000, 'reveal after both answer');

  const afterReveal = client0.getState().G;
  assert(afterReveal.rounds.length === 1, '[live server] round revealed to both after both answer');
  assert(
    afterReveal.rounds[0].answers['0'] === 'a' && afterReveal.rounds[0].answers['1'] === 'b',
    '[live server] revealed answers correct over the real network'
  );

  client0.stop();
  client1.stop();

  console.log(process.exitCode ? '\nIntegration check FAILED' : '\nIntegration check passed ✅');
  process.exit(process.exitCode || 0);
}

main().catch((err) => {
  console.error('Integration check crashed:', err);
  process.exit(1);
});
