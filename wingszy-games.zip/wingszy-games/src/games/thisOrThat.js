import { ActivePlayers } from 'boardgame.io/dist/esm/core.js';
import prompts from '../content/thisOrThat.json' with { type: 'json' };
import {
  simultaneousAnswerMove,
  allAnswered,
  revealAnswers,
  stripPendingAnswers,
} from './shared/simultaneousStage.js';

const ROUNDS_PER_MATCH = 8;

export const ThisOrThat = {
  name: 'this-or-that',

  setup: ({ ctx, random }) => ({
    // shuffled subset of prompts, same for both players
    prompts: random.Shuffle(prompts).slice(0, ROUNDS_PER_MATCH),
    currentPromptIndex: 0,
    rounds: [], // [{ promptIndex, answers: { '0': 'a'|'b', '1': 'a'|'b' } }, ...]
    secret: {
      pendingAnswers: {}, // stripped from clients via playerView
    },
  }),

  turn: {
    // Both seats can act during the same turn — required for a
    // simultaneous "pick one" round instead of alternating turns.
    activePlayers: ActivePlayers.ALL,
    // Pure predicate — no mutation allowed here.
    endIf: ({ G, ctx }) => allAnswered(G, ctx),
    // Mutation happens here instead, once the turn is ending.
    onEnd: ({ G, ctx, events }) => {
      revealAnswers(G, ctx);
      if (G.currentPromptIndex >= G.prompts.length) {
        events.endGame({ matchComplete: true });
      }
    },
  },

  moves: {
    // value is 'a' or 'b'
    submitAnswer: simultaneousAnswerMove,
  },

  playerView: stripPendingAnswers,

  minPlayers: 2,
  maxPlayers: 2,
};
