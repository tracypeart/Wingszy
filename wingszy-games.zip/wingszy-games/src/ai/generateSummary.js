/**
 * Turns the finished round history from aiCompatibility.js into a
 * short, memorable compatibility summary — the "You two would
 * absolutely destroy trivia night" line from the original brainstorm,
 * instead of a flat "92% match" score.
 *
 * Plug in your actual model call here (Claude, OpenAI, etc). Keeping
 * this OUTSIDE the boardgame.io game definition is intentional — see
 * the architecture note in src/games/aiCompatibility.js.
 */
export async function generateCompatibilitySummary(rounds) {
  const transcript = rounds
    .map((r, i) => {
      const p0 = r.answers['0'] ?? '';
      const p1 = r.answers['1'] ?? '';
      return `Q${i + 1}: Player A said "${p0}" — Player B said "${p1}"`;
    })
    .join('\n');

  // Example shape — replace with a real call to your model provider.
  // const response = await anthropic.messages.create({
  //   model: 'claude-sonnet-5',
  //   max_tokens: 200,
  //   messages: [{
  //     role: 'user',
  //     content: `Based on this compatibility quiz, write one punchy,
  //       specific sentence about these two people (not a percentage).
  //       Favor a nickname-style label like "Hopeless Foodies" or
  //       "Adventure Duo" plus one supporting line.\n\n${transcript}`,
  //   }],
  // });
  // const summary = response.content[0].text;

  const summary = `[stub] Compatibility summary would be generated here from:\n${transcript}`;

  // TODO: persist `summary` to your own datastore (Supabase table keyed
  // by matchID/userID pair), which your app reads separately from
  // boardgame.io's internal match state.
  return summary;
}
