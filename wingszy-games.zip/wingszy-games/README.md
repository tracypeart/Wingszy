# Wingszy Games — boardgame.io scaffold

A working scaffold for the 5-game MVP, built on boardgame.io. Two of the
games are turn-based (boardgame.io's native strength); three use a
custom "simultaneous private answer, then reveal together" pattern
layered on top, since boardgame.io doesn't have that built in.

## Games included

| Game | Pattern | Status |
|---|---|---|
| This or That | simultaneous reveal | fully working, integration-tested |
| Red Flag / Green Flag | simultaneous reveal | fully working |
| Cupid Draft | turn-based nomination + review | fully working |
| Build Our Perfect Date | simultaneous reveal, structured answer | fully working |
| AI Compatibility Challenge | simultaneous reveal, free-text + async summary hook | game logic working; AI call is stubbed (see below) |

## Setup

```bash
npm install
npm run server   # boardgame.io server on :8000
npm run dev      # Vite dev client on :3000 (in a second terminal)
```

Open `http://localhost:3000`. Pick a game, "Create match & join as seat 0"
in one browser tab, copy the Match ID shown, "Join an existing match" as
seat 1 in a second tab (or incognito window) to play against yourself.

## Architecture

- `src/games/*.js` — game definitions (state shape + moves + turn rules)
- `src/games/shared/simultaneousStage.js` — the reusable "both players
  answer privately, then reveal" pattern; This or That, Red/Green Flag,
  Build Our Date, and AI Compatibility all build on this
- `src/boards/*.jsx` — React UI for each game
- `src/lobby.js` — wraps boardgame.io's Lobby API (create/join matches);
  this is your actual "send a game invite" flow
- `src/server.js` — registers all 5 games on one boardgame.io server,
  plus a hook that fires when an AI Compatibility match ends
- `src/ai/generateSummary.js` — where the actual LLM call for the
  compatibility summary goes (stubbed — see below)

## The simultaneous-reveal pattern, and two real bugs it took to get right

boardgame.io is built around one player acting per turn. Getting "both
players answer privately at the same time" required three non-obvious
pieces, two of which only broke under a **real client-server connection**
— they looked completely fine in a pure in-memory test:

1. **`turn.activePlayers: ActivePlayers.ALL`** — lets both seats act
   during the same turn instead of strict alternation.
2. **`playerView` strips `G.secret`** before it reaches any client, so
   neither player can peek at the other's in-progress answer.
3. **Moves touching `G.secret` must be marked `client: false`.**
   boardgame.io runs moves optimistically on the client for instant
   feedback — but the client's local copy of `G` has `secret` already
   stripped by `playerView`, so a move that touches `G.secret` throws
   when boardgame.io tries to run it client-side. This only shows up
   once you're actually running two connected clients against a real
   server; an in-memory single-process test never exercises that code
   path and will pass even with this bug present.
4. **Reveal mutation belongs in `turn.onEnd`, not `turn.endIf`.**
   `endIf` is a pure predicate — boardgame.io calls it against a frozen
   Immer draft and mutating it throws `object is not extensible`. The
   fix is: `endIf` only decides *whether* to end the turn (`allAnswered`),
   and the actual reveal + advance-to-next-round mutation happens in
   `onEnd`, which does get a mutable draft.

Both of these were caught by `src/games/__integration_check.cjs`, which
boots the real server, creates a real match via the Lobby API, connects
two real Socket.IO clients, and plays a full round — not by code review.
Worth keeping (or something like it) as a smoke test before shipping
new games built on this pattern.

Tests:
```bash
node src/games/shared/__sanity_check.mjs   # pure logic, no network
node src/games/__integration_check.cjs     # real server + 2 live clients
```

## What's stubbed / left for you

- **AI summary generation** (`src/ai/generateSummary.js`) — the hook
  fires correctly when a match ends, but the actual model call is
  commented out. Swap in a real call to your Claude/OpenAI setup, and
  persist the result to your own database — not boardgame.io's store,
  which is meant for live match state, not permanent app data.
- **Auth / player identity** — the dev harness uses boardgame.io's
  `playerCredentials` directly. In production, tie match creation and
  joining to your actual logged-in users rather than the bare
  "Host"/"Guest" names used here.
- **Persistent storage** — by default boardgame.io's `Server()` keeps
  match state in memory, which is fine for dev but resets on restart.
  Swap in one of boardgame.io's storage adapters (Postgres, MongoDB,
  Firebase) before this goes anywhere near production.
- **Content** — `src/content/*.json` has ~15 starter prompts each for
  This or That and Red/Green Flag. Fine for testing, thin for launch;
  this is the easiest piece to expand or swap for a licensed API.
- **Emoji Story, Drawing Telephone, Friend Poll** — not built here, per
  the earlier recommendation: they don't fit boardgame.io's turn model
  well and are better served by plain Supabase Realtime + custom UI.

## Known packaging quirk

boardgame.io ships without a modern `exports` field, so raw Node's
strict ESM resolver can't follow `boardgame.io/core`,
`boardgame.io/server`, etc. as directory imports. Vite (and most
bundlers) handle this fine — you'll only hit it if you try to run
server-side code with plain `node`. This project's imports already use
the explicit `boardgame.io/dist/esm/*.js` / `boardgame.io/dist/cjs/*.js`
paths to sidestep it; keep that pattern if you add new games.
